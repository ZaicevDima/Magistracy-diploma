## AirMusic/AirAudio Magisk Module
You need to install the "AirMusic"-app (aka AirAudio) via Google-Play in order to use this module.
This module enables AirMusic's "system-mode" and allows you to stream all your audio to any network-enabled receiver.
